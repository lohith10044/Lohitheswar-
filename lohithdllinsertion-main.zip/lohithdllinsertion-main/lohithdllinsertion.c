#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *prev;
    struct node *next;
};

void insert(struct node **head, int data, int pos) {
    struct node *newnode = malloc(sizeof(struct node));

    newnode->data = data;
    newnode->prev = NULL;
    newnode->next = NULL;

    // Insert at first position
    if (pos == 1) {
        newnode->next = *head;

        if (*head != NULL) {
            (*head)->prev = newnode;
        }

        *head = newnode;
    }
    else {
        struct node *temp = *head;

        for (int i = 1; i < pos - 1 && temp != NULL; i++) {
            temp = temp->next;
        }

        if (temp != NULL) {
            newnode->next = temp->next;
            newnode->prev = temp;

            if (temp->next != NULL) {
                temp->next->prev = newnode;
            }

            temp->next = newnode;
        }
        else {
            printf("Invalid position\n");
            free(newnode);
        }
    }
}

void display(struct node *head) {
    while (head != NULL) {
        printf("%d ", head->data);
        head = head->next;
    }
}

int main() {
    struct node *head = NULL;

    insert(&head, 10, 1);
    insert(&head, 20, 2);
    insert(&head, 30, 3);

    display(head);

    return 0;
}
