#include<stdio.h>
#include<stdlib.h>
struct node {
int data;
struct node*next;
};
int main() {
struct node*head =NULL;
struct node*newnode;
newnode = (struct node*)malloc(sizeof(struct node));
printf("enter data:");
scanf("%d", &newnode->data);
newnode->next = head;
head = newnode;
printf("Linked List:");
printf("%d -> NULL\n",head->data);
return 0;
}
