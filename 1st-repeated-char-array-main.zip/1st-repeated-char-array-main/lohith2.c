#include<stdio.h>
int findfirstRepeated(int arr[],int size){
   for(int i = 0;i<size;i++){
      for (int j = i+1;j<size;j++){
         if (arr[i] == arr[j]){ 
            return arr[i];
         }
      }
    }
    return -1;
  }
  int main(){
      int arr[] = {10, 5, 3, 4, 3, 5, 6};
      int size = sizeof(arr) / sizeof(arr[0]);
      
      int result = findfirstRepeated(arr, size);
      
      if (result != -1){
         printf("The first repeated elment is: %d\n", result);
      } else {
           printf("no repeated elements found.\n");
        }   
  
     return 0;
    }
